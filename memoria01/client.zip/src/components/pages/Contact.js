import React, { useState } from "react";
import axios from '../../config/axios'

import "../../styles/Contact.css";

const Contact = (props) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const res = await axios.post('/api/userquery', formData);
      alert(res.data.message);
    } catch (error) {
      const res = error.response;
      alert(res.data.message);
    }
  };

  return (
    <>
      <div className="contact-container">
        <div className="contact-info">
          <p className="msg">"Thank you for contacting us. At Memoria, we value your input and are committed to providing the best possible customer experience. Our team of experts is dedicated to answering your questions and addressing any concerns you may have. Please feel free to explore our website to learn more about our products/services. We appreciate your interest in Memoria and look forward to working with you to meet your needs."</p>
          {/* <h2>Contact Information</h2>
          <h4>Address</h4>
          <p>Memoria, Chitkara University</p>
          <p>Rajpura, Patiala - 140401</p>
          <h4>Toll-Free Number</h4>
          <p><a href="tel:1800-00-0000">1800-00-0000</a></p>
          <h4>E-Mail</h4>
          <p><a href="mailto:memoria@gmail.org">memoria@gmail.org</a></p> */}
        </div>
        <div className="form-container">
          <h2 className="text-center">Contact Us</h2>
          <br></br>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="name">Name</label>
              <input
                type="text"
                name="name"
                className="form-control"
                id="name"
                placeholder="Enter your name"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="email"
                name="email"
                className="form-control"
                id="email"
                placeholder="Enter your email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="subject">Subject</label>
              <input
                type="text"
                name="subject"
                className="form-control"
                id="subject"
                placeholder="Subject"
                value={formData.subject}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="message">Message</label>
              <textarea
                name="message"
                className="form-control"
                id="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                required
              ></textarea>
            </div>
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default (Contact);