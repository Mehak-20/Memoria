import React from 'react';
import "../../styles/Home.css"

const Home = () => {
  return (
    <>
      <main>
        <section>
          <div class="fling-minislide">
            <img src={require("../../assets/Carousal Images/Img1.jpg")} alt="image1" />
            <img src={require("../../assets/Carousal Images/Img2.jpg")} alt="image2" />
            <img src={require("../../assets/Carousal Images/Img3.jpg")} alt="image3" />
            <img src={require("../../assets/Carousal Images/Img4.jpg")} alt="image4" />
            <img src={require("../../assets/Carousal Images/Img5.jpg")} alt="image5" />
          </div>

        </section>
        <section>
          <div className='welcome-message'>
            "Welcome to Memoria, your personal digital memory bank! We believe that every moment, big or small, deserves to be remembered and cherished forever. With Memoria, you can store and retrieve all your memories in one place, making it easy to relive your favorite moments and share them with your loved ones. Whether it's photos from your latest vacation, memories from a special event, or simply snapshots from your everyday life, we've got you covered. So sign up today and start building your personal collection of memories that you can cherish for years to come. We can't wait to see the amazing moments you'll capture with Memoria!"
          </div>
        </section>
        <section>
          <div class="services-grid">
            <h1>Testimonials</h1>
            <div class="service service1">
              <h4>Prateek</h4>
              <img src={require("../../assets/Testimonial Images/Img1.jpg")} alt="Testimonial1" />
              <p>"Memoria is the best app I've ever used for storing my memories. It's so easy to use, and I love being able to access my photos and events from anywhere. I highly recommend it!"</p>
              {/* <a class="cta">Read More &rarr;<span class="ti-angle-right"></span></a> */}
            </div>

            <div class="service service2">
              <h4>Marlyn</h4>
              <img src={require("../../assets/Testimonial Images/Img2.jpg")} alt='Testimonial2' />
              <p>"Memoria has made it so much easier to keep track of my family's memories. We love being able to access all of our photos and events in one place, and the app is so easy to use."</p>

              {/* <a href="#" class="cta">Read More &rarr;<span class="ti-angle-right"></span></a> */}
            </div>

            <div class="service service3">
              <h4>Jade</h4>
              <img src={require("../../assets/Testimonial Images/Img3.jpg")} alt='Testimonial3' />
              <p>"As someone who loves taking photos, I've always struggled with keeping them organized.It's so easy to use, and I love being able to quickly search for photos by event or date."</p>
              {/* <a href="#" class="cta">Read more &rarr;<span class="ti-angle-right"></span></a> */}
            </div>
          </div>
        </section>
      </main>

    </>
  )
}

export default Home