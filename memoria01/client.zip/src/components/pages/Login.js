import React, { useState } from 'react';
import "../../styles/Login.css";
import { Link } from "react-router-dom";
import axios from "../../config/axios"

const Login = () => {
  const [formdata, setformdata] = useState({
    email: "",
    userType: "",
    password: "",
  });



  const handle = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post('/api/auth/login', formdata);
      alert(res.data.message);
      sessionStorage.setItem("id", res.data.userId)
      if (res.data.redirectUrl) {
        // Perform the redirection using JavaScript
        window.location.href = res.data.redirectUrl;
      }
    } catch (error) {
      const res = error.response;
      alert(res.data.message);
    }
  };
  const handleonChange = (e) => {
    let val = e.target.value;
    let name = e.target.name;

    setformdata({ ...formdata, [name]: val })
  }

  return (
    <>
      <div className='form-container'>
        <form onSubmit={handle}>
          <h1>Login</h1>
          <label for="email">Email</label>
          <input type="email" id="email" name="email" value={formdata.email} onChange={handleonChange} placeholder='Enter Email' />
          <label for="password">Password</label>
          <input type="password" id="password" name="password" value={formdata.password} onChange={handleonChange} placeholder='Enter Password' />
          <div className='button-container'>
            <button type="submit">Log In</button>
            <Link to="/Signup">Don't have an account? Register Here!</Link>
          </div>
        </form>
      </div>
    </>
  )
}

export default Login