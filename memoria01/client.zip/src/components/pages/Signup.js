import React, { useState } from 'react';
import "../../styles/Signup.css";
import axios from '../../config/axios'
import { Link, useNavigate } from "react-router-dom";

const Signup = () => {
  const Navigate=useNavigate();

  const [formdata, setformdata] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })

  const handleonChange = (e) => {
    let val = e.target.value;
    let name = e.target.name;
    setformdata({ ...formdata, [name]: val })
  }

  const handle = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post('/api/auth/register', formdata);
      alert(res.data.message);
      if (res.status === 201) {
        Navigate('/Login');
      }

    } catch (error) {
      const res = error.response;
      alert(res.data.message);
      if (res.status === 409) {
        Navigate('/Login');
      }
    }
  };

return (
  <>
    <div className='form-container'>
      <form onSubmit={handle}>
        <h1>Sign Up</h1>
        <label htmlFor="email">Email</label>
        <input type="email" id="email" name="email" value={formdata.email} onChange={handleonChange} placeholder='Enter Email' />
        <label htmlFor="username">Username</label>
        <input type="text" id="name" name="name" value={formdata.name} onChange={handleonChange} placeholder='Enter Username' />
        <label htmlFor="password">Password</label>
        <input type="password" id="password" name="password" value={formdata.password} onChange={handleonChange} placeholder='Enter Password' />
        <label htmlFor="confirm-password">Confirm Password</label>
        <input type="password" id="confirmPassword" name="confirmPassword" value={formdata.confirmPassword} onChange={handleonChange} placeholder='Enter Confirm Password' />
        <div className='button-container'>
          <button type="submit">Sign Up</button>
          <Link to="/Login">Already have an account? Login Now!</Link>
        </div>
      </form>
    </div>
  </>
)
}

export default Signup